import java.util.Scanner;

public class BMI{
    
    public static void main(String[] args){
        
        Scanner put = new Scanner(System.in);
            System.out.println("Please enter your weight(kg):");
            double weight =put.nextDouble();
            
            System.out.println("Please enter height(m):");
            double height = put.nextDouble ();
      
            double BMI = weight/(height*height);
               
        System.out.print("BMI : "+BMI);
        
    }
}
