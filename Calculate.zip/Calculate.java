import java.util.Scanner;

public class Calculate {
    public static void main(String[] args) {
        
        Scanner um = new Scanner(System.in);
        int age1, age2,substraction;
        
        System.out.println("Please enter current year :");
        age1 = um.nextInt();
        
        System.out.println("Please enter birth year:");
        age2 = um.nextInt();

          substraction = age1 - age2;
          System.out.println("age= " + substraction);

          
    }
}


