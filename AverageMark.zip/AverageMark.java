import java.util.Scanner;

public class AverageMark{
    
    public static void main(String[] args){
        
        Scanner put = new Scanner(System.in);
            System.out.println("Please enter your name:");
            String name =put.nextLine ();
            
            System.out.println("Please enter Student ID :");
            String ID = put.nextLine ();
      
            System.out.println("Please enter the subject :");
            String subject = put.nextLine();
            
            System.out.println("Please enter test 1 marks :");
            double test1marks = put.nextDouble();
            
            System.out.println("Please enter test 2 marks :");
            double test2marks = put.nextDouble();
          
            double averagemark=(test1marks + test2marks)/2;
            put.close();
               
        System.out.println("Name :"+name);
        System.out.println("ID :"+ID);
        System.out.println("Subject :"+subject);
        System.out.println("Average Mark :"+averagemark);
    }
    }
