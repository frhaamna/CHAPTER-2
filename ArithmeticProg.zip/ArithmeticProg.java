import java.util.Scanner;

public class ArithmeticProg {
    public static void main(String[] args) {
        
        Scanner um = new Scanner(System.in);
        int num1, num2, addition, substraction, division, multiplication, modulus, increment1, increment2;
        
        System.out.println("Please enter first sum :");
        num1 = um.nextInt();
        
        System.out.println("Please enter second sum :");
        num2 = um.nextInt();
        
          addition = num1 + num2;
          System.out.println("add = " + addition);
          
          substraction = num1 - num2;
          System.out.println("subs = " + substraction);
          
          division = num1 / num2;
          System.out.println("devide = " + division);
          
          multiplication = num1 * num2;
          System.out.println("multiply = " + multiplication);
          
          modulus = num1 % num2;
          System.out.println("modul = " + modulus);
          
          increment1 = ++num1;
          increment2 = ++num2;
          
          System.out.println("increment1 = " +increment1);
          System.out.println("increment2 = " +increment2);
          
          um.close();
         
          
    }
}
