import java.util.Scanner;

public class UserInput {
    
    public static void main(String[] args){
        
        String name;
        int age;
        String hobby;
        String favoritefood;
        
        Scanner put = new Scanner(System.in);
            System.out.println("Please enter name:");
            name =put.nextLine ();
            
            System.out.println("Please enter age :");
            age=put.nextInt ();
      
            put.nextLine();
            System.out.println("Please enter hobby :");
            hobby=put.nextLine();
            
            System.out.println("Please enter favorite food :");
            favoritefood=put.nextLine();
            put.close();
               
        System.out.println("Name :"+name);
        System.out.println("Age :"+age);
        System.out.println("Hobby :"+hobby);
        System.out.println("Favorite food :"+favoritefood);
    }
}
