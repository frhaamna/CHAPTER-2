public class CompoundProg {
    public static void main(String[] args) {

        int a = 4, b = 2, c = 6, d = 9;

        System.out.println("Initial value of a: " + a);
        System.out.println("Pre-increment (++a): " + ++a); 
        System.out.println("Value of a after pre-increment: " + a);

        System.out.println("\nInitial value of b: " + b);
        System.out.println("Post-increment (b++): " + b++); 
        System.out.println("Value of b after post-increment: " + b);

        System.out.println("\nInitial value of c: " + c);
        System.out.println("Pre-decrement (--c): " + --c); 
        System.out.println("Value of c after pre-decrement: " + c);

        System.out.println("\nInitial value of d: " + d);
        System.out.println("Post-decrement (d--): " + d--);
        System.out.println("Value of d after post-decrement: " + d);
    }
}

