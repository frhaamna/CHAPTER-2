import java.util.Scanner;

public class Priceitem{
    
    public static void main(String[] args){
        
        Scanner put = new Scanner(System.in);
            System.out.println("Please enter item name:");
            String itemname =put.nextLine ();
            
            System.out.println("Please enter price :");
            double price = put.nextDouble ();
      
            System.out.println("Please enter the quantity :");
            int quantity = put.nextInt();
            
            System.out.println("Please enter discount rate :");
            double discountrate = put.nextDouble();
          
            double totalprice = price*quantity;
            double discount = totalprice * (discountrate/100);
            double priceafterdiscount = totalprice - discount;
               
        System.out.println("Item Name :"+itemname);
        System.out.println("Price : RM"+price);
        System.out.println("Quantity :"+quantity);
        System.out.println("Total Price : RM"+totalprice);
        System.out.println("Discount Rate :"+discountrate+"%");
        System.out.println("Price after Discount : RM"+priceafterdiscount);
    }
    }
